/*	$NetBSD: pathnames.h,v 1.2 1995/03/18 14:56:46 cgd Exp $	*/

#include <paths.h>

#define	_PATH_LKM	"/dev/lkm"
