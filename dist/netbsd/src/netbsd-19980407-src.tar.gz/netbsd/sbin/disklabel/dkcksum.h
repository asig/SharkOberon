u_short dkcksum __P((struct disklabel *));
