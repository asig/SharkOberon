/*	$NetBSD: date.h,v 1.3 1995/03/23 08:29:17 cgd Exp $ */

char datestring[] = "Tue Jul 23 1985";
