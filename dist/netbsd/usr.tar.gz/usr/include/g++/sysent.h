/* Provided for compatibity with other C++ compilers ONLY! */
#include <std.h>
