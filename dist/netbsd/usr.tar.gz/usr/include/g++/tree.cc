#include "tree.h"

__rb_tree_node_base __rb_NIL = { black, 0, 0, 0 };
