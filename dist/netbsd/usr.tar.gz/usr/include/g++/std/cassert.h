// The -*- C++ -*- assertions header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __ASSERT__
#define __ASSERT__
#include <assert.h>
#endif
