/*	$NetBSD: malloc.h,v 1.3 1994/10/26 00:56:03 cgd Exp $	*/

#include <stdlib.h>
