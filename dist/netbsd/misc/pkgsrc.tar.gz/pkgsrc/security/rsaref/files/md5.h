/* $NetBSD: md5.h,v 1.1.1.1 1998/03/18 00:49:33 tv Exp $ */
/* Include the system md5.h header file. */
#ifndef _MD5_H_
#include_next <md5.h>
#endif
