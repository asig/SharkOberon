package ncserver;

import java.awt.*;

public class DisposableFrame extends Frame {

	DisposableFrame(String title) {
		super(title);
	};

	public boolean handleEvent(Event e) {
		if (e.id == Event.WINDOW_DESTROY) {
			System.exit(0);
		};
		return super.handleEvent(e);
	};

};

