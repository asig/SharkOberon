package ncserver;

import java.applet.Applet;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class Config extends Applet {
	TextField gatewayAddress;
	TextField domainName;
	TextField dnsHostname;
	TextField subnetSpec, sizeField, baseAddr, numAddresses;
	TextField thisHostName;
	TextField thisHostAddress;
	Checkbox requireSmartCard;
	Checkbox moveServer, installDHCP;
	TextArea messageLog;
	Button setup;
	static DisposableFrame appletFrame;
	static boolean testing = false;
	String domainDefault;
	String primaryDefault;
	String localHostDefault;
	String localAddrDefault;

	public static void main(String[] args) {
		if (args.length == 0) {
			testing = false;
		} else if (args[0].equals("test")) {
			testing = true;
		} else {
			testing = false;
		};
		Config setupApplet = new Config();
		appletFrame = new DisposableFrame("NC Server Configuration"); 
		appletFrame.add("Center", setupApplet);
		setupApplet.setLayout(new BorderLayout());
		setupApplet.init();
		appletFrame.move(10, 10);
		appletFrame.pack();
		setupApplet.start();
		appletFrame.show();
	};

	public void init() {
		String resolvContents;
		StringTokenizer parser;
		String token;

		domainDefault = new String("");
		primaryDefault = new String("");
		localHostDefault = new String("");
		localAddrDefault = new String("");

		// parse /etc/resolv.conf to get defaults for the domain,
		// primary, secondary, and tertiary hosts.
		resolvContents = readFromFile("/etc/resolv.conf", true);
		parser = new StringTokenizer(resolvContents, "\t\n\r#", true);
		try {
			while (true) {
				token = parser.nextToken();
				if (token.equals("#")) {
					while (!token.equals("\n")) {
						token = parser.nextToken();
					};
				} else if (token.equals("domain")) {
					token = parser.nextToken();
					while (token.equals(" ") || token.equals("\n")
						|| token.equals("\t")) {
						token = parser.nextToken();
					};
					domainDefault = token;

				} else if (token.equals("nameserver")) {
					token = parser.nextToken();
					while (token.equals(" ") || token.equals("\n")
						|| token.equals("\t")) {
						token = parser.nextToken();
					};
					if (primaryDefault.length() == 0) {
						primaryDefault = token;
						break;
					};
				};
			};
		} catch (NoSuchElementException e) {
			// ran out of tokens, no problem
		};

		// See if there's a local host name. If so, use it as the
		// default.
		 try {
			localHostDefault = InetAddress.getLocalHost().getHostName();
			InetAddress localAddr = InetAddress.getByName(localHostDefault);
			String tempString = localAddr.toString();
			int slashPos = tempString.lastIndexOf("/");
			localAddrDefault = tempString.substring(slashPos+1);
			int dotPos = localHostDefault.indexOf(".");
			if (dotPos != -1) {
				tempString = localHostDefault.substring(0, dotPos);
				localHostDefault = tempString;
			};
		} catch (UnknownHostException e) {
			// No problem, we just need to prompt for a hostname and address.
		};
		// Set up application's input fields
		Panel p = new Panel();
		p.setLayout(new GridLayout(0,2));
		gatewayAddress = new TextField(30);
		p.add(new Label("Address of IP gateway (if any)  "));
		p.add(gatewayAddress);
		thisHostName = new TextField(localHostDefault, 30);
		p.add(new Label("Name of this host "));
		p.add(thisHostName);
		thisHostAddress = new TextField(localAddrDefault, 30);
		p.add(new Label("Address of this host "));
		p.add(thisHostAddress);
		domainName = new TextField(domainDefault, 30);
		p.add(new Label("Domain Name "));
		p.add(domainName);
		dnsHostname = new TextField(primaryDefault, 30);
		p.add(new Label("Name Server (if any) "));
		p.add(dnsHostname);
		subnetSpec = new TextField(30);
		p.add(new Label("Subnet and Mask for NC Network (e.g. 14.15.16.0 255.255.255.0)"));
		p.add(subnetSpec);
		sizeField = new TextField("2", 30);
		p.add(new Label("NC Swap File Sizes (in megabytes)"));
		p.add(sizeField);
		baseAddr = new TextField(30);
		p.add(new Label("First address to assign to an NC"));
		p.add(baseAddr);
		numAddresses = new TextField(30);
		p.add(new Label("Number of addresses to assign to NCs "));
		p.add(numAddresses);
		moveServer = new Checkbox("Change this server's address?", null, false);
		p.add(moveServer);
		installDHCP = new Checkbox("Configure and install dhcp?", null, true);
		p.add(installDHCP);
		requireSmartCard = new Checkbox("Require smart card login?", null, true);
		File nciFile = new File("./ncusr/usr/local/nc/client/netbsd/arm32/bin/xinitrc");
		File nciTar = new File("/tar/nci.tar.gz");
		if (nciFile.exists() || nciTar.exists()) {
			p.add(requireSmartCard);
		};
		setup = new Button("Configure");
		p.add(setup);
		this.add("North", p);
		messageLog = new TextArea(8, 60);
		this.add("South", messageLog);
	};

	public boolean action(Event e, Object o) {
		 if (e.target == setup) {
			// The user clicked the "Configure" button. Do the setup.
			String size = new String("");
			String dirString = new String("");
			String dnsHost = dnsHostname.getText();
			String dnsAddrString = new String("");
			String gatewayAddr = gatewayAddress.getText();
			String domain = domainName.getText();
			String localHost = thisHostName.getText();
			String localAddress = thisHostAddress.getText();
			long addresses = 0;
			long baseAddress = 0;
			boolean updateServer = moveServer.getState();
			boolean doDHCP = installDHCP.getState();
			boolean smartCard = requireSmartCard.getState();
			boolean error = false;

			// Do as much checking on the data we're given as we can.
			// If there's a problem, note the problem and allow the
			// user to change the info.
			try {
				dirString = getDirectory();

				// Check to see if the code is already unpacked. If not,
				// unpack it.
				unpackCode(dirString);
				checkDirectory();

				testWritable();
				size = checkAndConvertSize();
				addresses = checkAndConvertAddresses();
				checkGateway(gatewayAddr);

				if (domain.length() == 0) {
					messageLog.appendText("Domain name must be specified\n");
					return true;
				};

				// make sure hostname is valid and if the dotted
				// decimal form was specified, set host to null
				dnsAddrString = getAddressString(dnsHost);
				dnsHost = checkHostName(dnsAddrString, dnsHost);

				checkSwapScript(dirString);
				baseAddress = getBaseAndCheckAlloc(addresses);
			} catch (InputException exc) {
				error = true;
			};
			if (error) {
				return true;
			};

			// Do the setup.
			updateMkClient(domain, dirString, localHost);
			addResolvConf(domain, dnsHost, dnsAddrString, updateServer);
			if (testing) {
				addToFile("/usr -maproot=0 -alldirs", "\n/usr",
					"../../etc/exports", new String(""), true);
			} else {
				addToFile("/usr -maproot=0 -alldirs", "\n/usr", "/etc/exports", new String(""), true);
			};
			updatefstab(dirString, localAddress, updateServer, localAddrDefault);
			if (updateServer) {
				if ((localHostDefault.length() != 0 && 
					!localHostDefault.equals(localHost)) 
					|| (localAddrDefault.length() != 0 && 
					!localAddrDefault.equals(localAddress))) {
					replaceAddr(domain, localHostDefault, 
						localHost, localAddrDefault,
						localAddress, gatewayAddr); 
				};
			};
			addMountdOption();
			setupBootConfig(dirString);
			makeSwapSpaces(addresses, size, dirString, baseAddress, updateServer);
			setupDHCP(gatewayAddr, domain, dnsHost, dnsAddrString, 
				baseAddress, addresses, dirString, localHost, 
				localAddress, doDHCP);
			changeSmartCard(dirString, smartCard);
			messageLog.appendText("Configuration finished.\n");
			return true;
		} else {
			return false;
		};
	};

	// Make sure that all of the directories we need to write to are
	// writable.
	private void testWritable() throws InputException {
		File testFile = new File("./ncroot/root/etc");
		boolean writable = testFile.canWrite();
		if (!writable) {
			messageLog.appendText("You aren't allowed to write to ./ncroot/root/etc.\n");
			throw new InputException();
		};
		if (testing) {
			testFile = new File("../../etc");
		} else {
			testFile = new File("/etc");
		};
		writable = testFile.canWrite();
		if (!writable) {
			messageLog.appendText("You aren't allowed to write to /etc");
			throw new InputException();
		};
		if (testing) {
			testFile = new File("../../usr");
		} else {
			testFile = new File("/usr");
		};
		writable = testFile.canWrite();
		if (!writable) {
			messageLog.appendText("You aren't allowed to write to /usr");
			throw new InputException();
		};
	};

	private void changeSmartCard(String directory, boolean addIt) {
		String xinitName = new String("/ncusr/usr/local/nc/client/netbsd/arm32/bin/xinitrc");
		String emptyString = new String("");
		File xinitrc = new File(directory + xinitName);
		if (!xinitrc.exists()) {
			// no problem
			return;
		};
		if (addIt) {
			addToFile("LOGIN_OPTS=\"-login\"", "#LOGIN_OPTS=\"-login\"", directory + xinitName, emptyString, false); 
			addToFile("#LOGIN_OPTS=\" \"", "LOGIN_OPTS=\" \"", directory + xinitName, emptyString, false);
		} else {
			addToFile("#LOGIN_OPTS=\"-login\"", "LOGIN_OPTS=\"-login\"", directory + xinitName, emptyString, false);
			addToFile("LOGIN_OPTS=\" \"", "#LOGIN_OPTS=\" \"", directory + xinitName, emptyString, false);
		};
	};

	private void unpackCode(String dirName) throws InputException {
		File markerFile = new File("./unpacked");
		String tarDirName;
		String tarPrefix;
		File ncuser = new File("./ncusr");
		File ncroot = new File("./ncroot/root");
		File dhcp = new File("./dhcp");

		if (testing) {
			tarDirName = "../../tar";
			tarPrefix = "../../tar/";
		} else {
			tarDirName = "/tar";
			tarPrefix = "/tar/";
		};
		ncuser.mkdirs();
		ncroot.mkdirs();
		dhcp.mkdirs();
		File tarDir = new File(tarDirName);
		String[] x11List = tarDir.list(new X11Filter());
		if (x11List.length == 0) {
			// The files are already unpacked and on a CD.
			return;
		};
		if (!markerFile.exists()) {
			messageLog.appendText("Unpacking tar files, this will take awhile.\n");
			messageLog.repaint();
		};
		// Check for tarfiles and unpack as we go
		if (!findAndUnpackFile(x11List, tarPrefix, dirName + "/ncusr")) 
			throw new InputException();

		String[] nciList = tarDir.list(new NCIFilter());
		if (nciList.length != 0) {
			if (!findAndUnpackFile(nciList, tarPrefix, dirName+ "/ncusr")) 
				throw new InputException();
			String[] nciRootList = tarDir.list(new NCIRootFilter());
			if (nciRootList.length != 0) {
				if (!findAndUnpackFile(nciRootList, tarPrefix, dirName + "/ncroot/root"))
				throw new InputException();
			} else {
				messageLog.appendText("The nci-root tarfile is missing. You'll need to get it.\n");
				throw new InputException();
			};
			String[] javaList = tarDir.list(new JavaFilter());
			if (javaList.length != 0) {
				if (!findAndUnpackFile(javaList, tarPrefix, dirName + "/ncusr")) 
					throw new InputException();
			} else {
				messageLog.appendText("The java tarfile is missing. You'll need to get it.\n");
				throw new InputException();
			};
		} else {
			String[] rootList = tarDir.list(new RootFilter());
			if (rootList.length != 0) {
				if (!findAndUnpackFile(rootList, tarPrefix, dirName + "/ncroot/root")) 
					throw new InputException();
			} else {
				messageLog.appendText("The root tarfile is missing. You'll need to get it.\n");
				throw new InputException();
			};
		};
		String[] usrList = tarDir.list(new UsrFilter());
		if (usrList.length != 0) {
			if (!findAndUnpackFile(usrList, tarPrefix, dirName + "/ncusr")) 
				throw new InputException();
		} else {
			messageLog.appendText("The usr tarfile is missing. You'll need to get it.\n");
			throw new InputException();
		};
		String[] dhcpList = tarDir.list(new DHCPFilter());
		if (dhcpList.length != 0) {
			if (!findAndUnpackFile(dhcpList, tarPrefix, dirName + "/dhcp")) 
				throw new InputException();
		} else {
			messageLog.appendText("The dhcp tarfile is missing. You'll need to get it.\n");
			throw new InputException();
		};
	};

	private boolean findAndUnpackFile(String[] files, String tarPrefix, String dirName) {
		File temp;
		Process unpacker;
		int exitVal;
		Runtime rt = Runtime.getRuntime();
		boolean allOK = true;
		String filename;
		String markerContents = readFromFile("./unpacked", false);

		filename = getLatest(files);
		if (!alreadyUnpacked(filename, markerContents)) {
			try {
				messageLog.appendText("Unpacking " + tarPrefix + filename + ".\n");
				messageLog.repaint();
				temp = new File(tarPrefix + filename);
				if (!temp.exists()) {
					messageLog.appendText("Can't find " + tarPrefix + filename + " You need to either NFS mount the file\n");
					messageLog.appendText(" system where the tarfiles are stored, or copy the tarfiles to /tar.\n"); 
					allOK = false;
				};
				String tarString = "/usr/bin/tar --unlink -xpzf " + tarPrefix + filename + " -C " + dirName;
				unpacker = rt.exec(tarString);
				exitVal = unpacker.waitFor();
				if (exitVal != 0) {
					messageLog.appendText("Problem unpacking " + tarPrefix + filename + "\n");
					allOK = false;
				};
			} catch (IOException e) {
				messageLog.appendText("Problem unpacking tarfiles, exception is: ");
				messageLog.appendText(e.toString() + "\n");
				allOK = false;
			} catch (InterruptedException e) {
				messageLog.appendText("Interrupted while unpacking tarfiles, you'll need to start over.\n");
				allOK = false;
			};
			if (allOK) writeFile(markerContents + filename + "\n", "./unpacked");
		};
		return allOK;
	};

	private String getLatest(String[] fileList) {
		String returnString = fileList[0];
		if (fileList.length > 1) {
			for (int i = 1; i < fileList.length; i++) {
				if (fileList[i].compareTo(returnString) > 0)
					returnString = fileList[i];
			};
		};
		return returnString;
	};

	private boolean alreadyUnpacked(String filename, String markerContents) {
		if (markerContents.length() == 0) return false;
		if (markerContents.indexOf(filename) != -1) return true;
		return false;
	};

	private long addrToLong(String toConvert) {
		StringTokenizer st = new StringTokenizer(toConvert, ".");
		long addr[] = new long[4];
		int partsPresent = 4;
		long returnValue = 0;

		for(int i=0; i < addr.length; i++) {
			if (st.hasMoreTokens()) {
				long thisPiece = Integer.parseInt(st.nextToken());
				if (thisPiece < 0 || thisPiece > 255) {
					// Not a valid address
					return 0;
				};
				addr[i] = thisPiece;
			} else {
				partsPresent = i;
				break;
			};
		};
		if (partsPresent > 0) {
			returnValue = returnValue + (addr[0] << 24) & 0xFF000000;
		};
		if (partsPresent > 1) {
			returnValue |= (addr[1] << 16) & 0xFF0000;
		};
		if (partsPresent > 2) {
			returnValue |= (addr[2] << 8) & 0xFF00;
		};
		if (partsPresent > 3) {
			returnValue |= addr[3] & 0xFF;
		};
		return returnValue;
	};

	private void writeFile(String contents, String filename) {
		PrintStream pout;
		FileOutputStream fout;
		try {
			fout = new FileOutputStream(filename);
			pout = new PrintStream(fout);
			pout.print(contents);
			pout.close();
		} catch (IOException e) {
			messageLog.appendText("Couldn't write file " + filename + "\n");
			messageLog.appendText(e.toString());
			messageLog.appendText("\n");
		};
	};

	// Use the hostname we were given to get its IP address.
	private String getAddressString(String hostname) throws InputException {
		InetAddress dnsAddr;
		String addrString, returnString;
		int slashPos;

		returnString = new String("");
		try {
			if (hostname.length() != 0) {
				dnsAddr = InetAddress.getByName(hostname);
				addrString = dnsAddr.toString();
				slashPos = addrString.lastIndexOf("/");
				returnString = addrString.substring(slashPos+1);
			};
		} catch (UnknownHostException e) {
			messageLog.appendText("Can't lookup hostname. If there's no DNS, use dotted decimal format.\n");
			throw new InputException();
		};
		return returnString;
	};

	private void replaceAddr(String domain, String oldHost, String newHost,
		String oldAddr, String newAddr, String newGatewayAddr) {
		String subnet = subnetSpec.getText();
		String maskString;
		int slashPos = subnet.indexOf("/");
		if (slashPos == -1) {
			int spacePos = subnet.indexOf(" ");
			maskString = subnet.substring(spacePos+1, subnet.length());
		} else {
			String tempString = subnet.substring(0, slashPos);
			long subnetBase = addrToLong(tempString);
			tempString = subnet.substring(slashPos+1, subnet.length());
			long mask = 0xFFFFFFFF & (~Long.parseLong(tempString));
			maskString = addrToString(mask);
		};
		String tempString = newAddr + " " + newHost + "." + domain + " " + newHost;
		String emptyString = new String("");
		String targetFilePrefix;
		if (testing) targetFilePrefix = "../..";
		else targetFilePrefix = emptyString;
		addToFile(tempString, oldAddr, targetFilePrefix + "/etc/hosts", emptyString, true); 
		tempString = newAddr + " " + newHost + "." + domain + ".";
		addToFile(tempString, oldAddr, targetFilePrefix + "/etc/hosts", emptyString, true);
		tempString = "hostname=\"" + newHost + "." + domain + "\"";
		addToFile(tempString, "hostname=", targetFilePrefix + "/etc/rc.conf",
			emptyString, true);
		addToFile(tempString, "hostname=", targetFilePrefix + "/etc/sysconfig", emptyString, false);
		String fileContents = readFromFile(targetFilePrefix + "/etc/rc.conf", true);
		if (fileContents.length() != 0) {
			int targetIndex = fileContents.indexOf(oldAddr);
			if (targetIndex != -1) {
				int lastCRIndex = fileContents.lastIndexOf("\n", targetIndex);
				if (lastCRIndex == -1) lastCRIndex = 0;
				tempString = fileContents.substring(lastCRIndex + 1, targetIndex);
				tempString = tempString + newAddr + " netmask " + maskString + "\"";
				addToFile(tempString, oldAddr, 
					targetFilePrefix + "/etc/rc.conf", 
					emptyString, true);
				addToFile(tempString, oldAddr, 
					targetFilePrefix + "/etc/sysconfig", 
					emptyString, false);
			};
		};

		if (newGatewayAddr.length() > 0) {
			tempString = "defaultrouter=\"" + newGatewayAddr + "\"";
			addToFile(tempString, "defaultrouter=", 
				targetFilePrefix + "/etc/rc.conf", emptyString, 
				false);
			addToFile(tempString, "defaultrouter=", 
				targetFilePrefix + "/etc/sysconfig", 
				emptyString, false);
		};
	 	fileContents = readFromFile(targetFilePrefix + "/etc/motd", true);
		if (fileContents.length() != 0) {
			int releaseIndex = fileContents.indexOf("RELEASE");
			if (releaseIndex != -1) {
				int lastCRIndex = fileContents.lastIndexOf("\n", releaseIndex);
				tempString = fileContents.substring(lastCRIndex + 1, releaseIndex);
				int parenIndex = fileContents.indexOf("(", releaseIndex);
				tempString = tempString + fileContents.substring(releaseIndex, parenIndex);
				tempString = tempString + "(" + newHost + ")";
				parenIndex = fileContents.indexOf(")", releaseIndex);
				lastCRIndex = fileContents.indexOf("\n", releaseIndex);
				tempString = tempString + fileContents.substring(parenIndex + 1, lastCRIndex);
				addToFile(tempString, "RELEASE (", targetFilePrefix + "/etc/motd", emptyString, false);
			};
		};
	};

	private void addResolvConf(String domain, String dnsHost, String dnsAddr,
		boolean updateServer) {
		messageLog.appendText("Adding /usr/shark/ncroot/root/etc/resolv.conf.\n");
		File resolvFile = new File("./ncroot/root/etc/resolv.conf");
		File resolvOrig = new File("./ncroot/root/etc/resolv.conf.orig");
		String resolvText;

		if (resolvOrig.exists()) {
			resolvOrig.delete();
		};
		if (resolvFile.exists()) {
			messageLog.appendText("resolv.conf already exists. Renaming it to resolv.conf.orig\n");
			resolvFile.renameTo(resolvOrig);
		};
		resolvText = new String("domain " + domain + "\n");
		if (dnsAddr.length() != 0) {
			resolvText = resolvText + "nameserver " +  dnsAddr + " " + dnsHost + "\n";
		};
		writeFile(resolvText, "./ncroot/root/etc/resolv.conf");
		if (!domainDefault.equals(domain) || !primaryDefault.equals(dnsAddr)) {
			// See if the user also wants to update /etc/resolv.conf
			if (updateServer) {
				String etcResolvName;
				String etcOrigName;
				File etcResolv;
				File etcOrig;
				if (testing) {
					etcResolvName = "../../etc/resolv.conf";	
				} else {
					etcResolvName = "/etc/resolv.conf";
				};
				etcOrigName = etcResolvName + ".orig";
				etcResolv = new File(etcResolvName);
				etcOrig = new File(etcOrigName);
				if (etcOrig.exists()) {
					etcOrig.delete();
				};
				if (etcResolv.exists()) {
					messageLog.appendText(etcResolvName + " already exists. Renaming it to " + etcOrigName + "\n");
					etcResolv.renameTo(etcOrig);
				};
				writeFile(resolvText, etcResolvName);
			};
		};
	};

	private void updatefstab(String directory, String localHost, boolean updateServer,
		String oldAddr) {
		String fstabContents;
		String newfstabContents;
		String searchString = new String("sharking");
		int searchIndex;
		int endIndex;
		int tempIndex;

		messageLog.appendText("Updating ./ncroot/root/etc/fstab.\n");
		fstabContents = readFromFile("./ncroot/root/etc/fstab", true);
		if (fstabContents.length() == 0) return;
		if (updateServer) {
			searchString = oldAddr;	
		};
		searchIndex = fstabContents.indexOf(searchString);
		if (searchIndex == -1) return;
		newfstabContents = fstabContents.substring(0, searchIndex);
		endIndex = fstabContents.indexOf(" ", searchIndex);
		tempIndex = fstabContents.indexOf("	", searchIndex);
		if (endIndex == -1) {
			endIndex = tempIndex;
		} else if (tempIndex != -1) {
			endIndex = Math.min(endIndex, tempIndex);
		};
		newfstabContents = newfstabContents + localHost + ":" + directory + "/ncroot/root";
		newfstabContents = newfstabContents + fstabContents.substring(endIndex, fstabContents.length());
		fstabContents = newfstabContents;
		searchIndex = fstabContents.indexOf(searchString);
		newfstabContents = fstabContents.substring(0, searchIndex);
		endIndex = fstabContents.indexOf(" ", searchIndex);
		tempIndex = fstabContents.indexOf("	", searchIndex);
		if (endIndex == -1) {
			endIndex = tempIndex;
		} else if (tempIndex != -1) {
			endIndex = Math.min(endIndex, tempIndex);
		};
		newfstabContents = newfstabContents + localHost + ":" + directory + "/ncusr/usr";
		newfstabContents = newfstabContents + fstabContents.substring(endIndex, fstabContents.length());
		writeFile(newfstabContents, "./ncroot/root/etc/fstab");
	};

	private String readFromFile(String filename, boolean reportError) {
		FileInputStream fileIn;
		byte[] fileBytes;
		int bytesRead;
		String contents = new String("");

		try {
			fileIn = new FileInputStream(filename);
			fileBytes = new byte[fileIn.available()];
			bytesRead = fileIn.read(fileBytes);
			contents = new String(fileBytes, 0);
			fileIn.close();
		} catch (IOException e) {
			if (reportError) {
				messageLog.appendText("Problem with " + filename + ".\n");
				messageLog.appendText("Exception is " + e.toString() + "\n");
			};
		};

		return contents;
	};

	private int getFirstNonComment(String searchString, String target) {
		int toReturn = searchString.indexOf(target);
		if (target.charAt(0) != '\n') {
			while (true) {
				int tempIndex = searchString.lastIndexOf("\n", toReturn);
				if (searchString.charAt(tempIndex+1) == '#') {
					toReturn = searchString.indexOf(target, toReturn+1);
					if (toReturn == -1) {
						break;
					};
				} else {
					break;
				};
			};
		};
		return toReturn;
	};

	private void addToFile(String stringToAdd, String checkExists, String fileName,
		String addAfter, boolean createFile) {
		String fileContents;
		byte[] fileBytes;
		int bytesRead;

		messageLog.appendText("Adding " + stringToAdd + " to " + fileName + ".\n");
		fileContents = readFromFile(fileName, false);
		if (fileContents.length() != 0) {
			int targetIndex;
			if (checkExists.charAt(0) != '#') targetIndex =getFirstNonComment(fileContents, checkExists);
			else targetIndex = fileContents.indexOf(checkExists);
			if (targetIndex == -1) {
				// Didn't find target string. If addAfter specified,
				// find the string to add this one after. Otherwise,
				// append this string to the end of the file.
				if (addAfter.length() == 0 || fileContents.indexOf(addAfter) == -1) {
					// Didn't find string to add after, append
					// to end of file
					fileContents = fileContents + stringToAdd + "\n";
				} else {
					String tempContents;
					targetIndex = fileContents.indexOf(addAfter);
					int addPosition = fileContents.indexOf("\n", targetIndex);
					tempContents = fileContents.substring(0, addPosition+1);
					tempContents = tempContents + stringToAdd + "\n";
					tempContents = tempContents + fileContents.substring(addPosition+1, fileContents.length());
					fileContents = tempContents;
				};
			} else {
				// Overwrite this line of the file with stringToAdd.
				int tempIndex;
				if (checkExists.charAt(0) == '\n') {
					tempIndex = fileContents.lastIndexOf("\n", targetIndex+1);
				} else {
					tempIndex = fileContents.lastIndexOf("\n", targetIndex);
				};
				String tempContents = fileContents.substring(0, tempIndex+1);	
				tempContents = tempContents + stringToAdd + "\n";
				tempIndex = fileContents.indexOf("\n", targetIndex+1);
				if (tempIndex != -1) {
					tempContents = tempContents + fileContents.substring(tempIndex+1, fileContents.length());
				};
				fileContents = tempContents;
				
			};
		} else if (createFile) {
			fileContents = "#Automatically created by NC configuration utility.\n";
			fileContents = fileContents + stringToAdd + "\n";
		} else return;
		writeFile(fileContents, fileName);
	};

	private void addMountdOption() {
		String mountdContents;
		StringTokenizer parser;
		String token;
		int mountdIndex;
		int tempIndex;
		String searchSubstring;
		String echoSearchSubstring;
		String tempSubstring;
		String newMountd = new String("");
		String mountdFileName;

		messageLog.appendText("Adding the -r option to mountd in /etc/rc.network.\n");
		if (testing) {
			mountdFileName = "../../etc/rc.network";
		} else {
			mountdFileName = "/etc/rc.network";
		};
		mountdContents = readFromFile(mountdFileName, true);
		if (mountdContents.length() == 0) return;
		searchSubstring = mountdContents;
		echoSearchSubstring = mountdContents;

		while ((mountdIndex = searchSubstring.indexOf("mountd")) != -1) {
			echoSearchSubstring = searchSubstring.substring(0, mountdIndex);
			newMountd = newMountd + echoSearchSubstring;
			if ((mountdIndex-1 > 0) && !(Character.isSpace(
				searchSubstring.charAt(mountdIndex-1)) ||
				searchSubstring.charAt(mountdIndex-1) == ';')) {
				tempSubstring = searchSubstring.substring(mountdIndex+6,
					searchSubstring.length());
				searchSubstring = tempSubstring;
				newMountd = newMountd + "mountd";
				if (searchSubstring.indexOf("mountd") == -1) {
					// tack on the rest of the file
					newMountd = newMountd + searchSubstring;
				};
				continue;
			};
			if ((mountdIndex+6 < searchSubstring.length()) && 
				!(Character.isSpace(searchSubstring.charAt(mountdIndex+6)) ||
				searchSubstring.charAt(mountdIndex+6) == '-' ||
				searchSubstring.charAt(mountdIndex+6) == ';' ||
				searchSubstring.charAt(mountdIndex+6) == ''')) {
				tempSubstring = searchSubstring.substring(mountdIndex+6,
					searchSubstring.length());
				searchSubstring = tempSubstring;
				newMountd = newMountd + "mountd";
				if (searchSubstring.indexOf("mountd") == -1) {
					// tack on the rest of the file
					newMountd = newMountd + searchSubstring;
				};
				continue;
			};
			tempSubstring = searchSubstring.substring(mountdIndex+6, searchSubstring.length());
			searchSubstring = tempSubstring;

			// Find out if this is in the middle of an echo statement in which
			// case the -r option shouldn't be added, otherwise add it.
			tempIndex = echoSearchSubstring.lastIndexOf("echo");
			if (tempIndex == -1) {
				// need to check whether the -r option is there
				tempIndex = searchSubstring.indexOf("-r");
				if (tempIndex == -1) {
					// this instance of mountd doesn't have 
					// the -r option. Add it.
					newMountd = newMountd + "mountd -r";
				} else {
					// need to see if the -r option really belongs to mountd
					int tempIndex2;
					int tempIndex3;
					int i;
					boolean addROption = false;

					tempIndex2 = searchSubstring.indexOf("\n");
					tempIndex3 = searchSubstring.indexOf(";");
					tempIndex2 = Math.min(tempIndex2, tempIndex3);
					if (tempIndex < tempIndex2) {
						// If the -r option is between the mountd
						// and the first CR or semicolon, check
						// to see if there's anything other than
						// options in between.
						for (i=0; i < tempIndex; i++) {
							if (searchSubstring.charAt(i) == '-') {
								if (!Character.isLetter(searchSubstring.charAt(i+1))) {
									addROption = true;
									break;
								};
							} else if (Character.isLetter(searchSubstring.charAt(i)) && searchSubstring.charAt(i-1) == '-') {
								// found an option. Keep going
							} else if (!Character.isSpace(searchSubstring.charAt(i))) {
								addROption = true;
								break;
							};
						};
					} else {
						// the -r option didn't belong to this
						// instance of mountd, need to add it.
						addROption = true;
					};
					if (addROption) {
						newMountd = newMountd + "mountd -r";		
					} else {
						newMountd = newMountd + "mountd";
					};
				};
			} else {
				// see if there are any carriage returns or 
				// semicolons between the echo and the mountd
				int i;
				boolean addROption = false;
				for (i=tempIndex; i < echoSearchSubstring.length(); i++) {
					if (echoSearchSubstring.charAt(i) == '\n' ||
						echoSearchSubstring.charAt(i) == ';') {
						addROption = true;
					};
				};
				if (addROption) {
					newMountd = newMountd + "mountd -r";	
				} else {
					newMountd = newMountd + "mountd";
				};
			};
					
			if (searchSubstring.indexOf("mountd") == -1) {
				// tack on the rest of the file
				newMountd = newMountd + searchSubstring;
			};
		};
		if (newMountd.length() == 0) return;
		writeFile(newMountd, mountdFileName);
	};

	// This script is still in use for development, so if the file
	// exists, update it, otherwise, ignore it.
	private void updateMkClient(String domain, String dirname, String localHost) {
		File mkClient = new File("./mkclient");

		if (!mkClient.exists()) return;
		String emptyString = new String("");
		addToFile("SERVER=" + localHost, "SERVER=", "./mkclient", emptyString, false);
		addToFile("DOMAIN=" + domain, "DOMAIN=", "./mkclient", emptyString, false);
		addToFile("ARMROOT=" + dirname, "ARMROOT=", "./mkclient", emptyString, false);
		messageLog.appendText("Updating ./mkclient to reflect current domain and hostnames.\n");
	};

	// copy netbsd to /usr/tftpboot, edit inetd.conf to include boot
	// line and the -s option (for security)
	// send a SIGHUP to inetd to make it aware of the changes.
	private void setupBootConfig(String directory) {
		File bootDir;
		FileInputStream netbsdIn;
		FileOutputStream netbsdOut;
		String bootDirName;
		byte[] netbsdBytes = new byte[8192];
		messageLog.appendText("Copying netbsd to /usr/tftpboot\n");
		if (testing) {
			bootDirName = "../../usr/tftpboot";
		} else {
			bootDirName = "/usr/tftpboot";
		};
		bootDir = new File(bootDirName);
		bootDir.mkdirs();
		try {
			netbsdIn = new FileInputStream(directory + "/ncroot/root/netbsd");
			netbsdOut = new FileOutputStream(bootDirName + "/netbsd");
			int bytesToWrite = netbsdIn.available();
			while (bytesToWrite != 0) {
				if (bytesToWrite < 8192) {
					netbsdBytes = new byte[bytesToWrite];
					bytesToWrite = 0;
				} else {
					bytesToWrite -= 8192;
				};
				netbsdIn.read(netbsdBytes);
				netbsdOut.write(netbsdBytes);
			};
			netbsdIn.close();
		} catch (IOException e) {
			messageLog.appendText("The netbsd bootfile could not be copied to /usr/tftpboot \n");
			messageLog.appendText(" because of the following exception:" + e.toString() + "\n");
			messageLog.appendText("You'll need to get it from " + directory + "/ncroot/root, \n");
			messageLog.appendText("copy it to /usr/tftpboot, and update the inetd.conf file appropriately.\n");
			return;
		};
		messageLog.appendText("Uncommenting the tftp line in inetd.conf.\n");
		String inetName;
		String inetContents;
		String tempString;
		String newInetContents;
		int filePos, poundPos;
		boolean commented;
		if (testing) {
			inetName = "../../etc/inetd.conf";
		} else {
			inetName = "/etc/inetd.conf";
		};
		inetContents = readFromFile(inetName, true);
		if (inetContents.length() == 0)  return;
		newInetContents = inetContents;
		commented = false;
		filePos = inetContents.indexOf("tftp");
		if (filePos == -1) {
			messageLog.appendText("Can't find tftp line in inetd.conf, you'll need to update it manually.\n");
			return;
		};
		poundPos = filePos - 1;
		while (inetContents.charAt(poundPos) != '\n' && inetContents.charAt(poundPos) != '#') {
			poundPos = poundPos - 1;
		};
		if (inetContents.charAt(poundPos) == '#') {
			commented = true;
		};
		if (commented) {
			tempString = inetContents.substring(0, poundPos);
			newInetContents = tempString;
			tempString = inetContents.substring(poundPos+1, inetContents.length());
			newInetContents = newInetContents + tempString;
		};
		filePos = newInetContents.indexOf("tftpd");
		// We need the second instance of tftpd
		filePos = newInetContents.indexOf("tftpd", filePos+1);
		int eolPos = newInetContents.indexOf("\n", filePos);
		inetContents = newInetContents;
		tempString = inetContents.substring(0, filePos);
		newInetContents = tempString + "tftpd /usr/tftpboot\n";
		tempString = inetContents.substring(eolPos+1, inetContents.length());
		newInetContents = newInetContents + tempString;
		writeFile(newInetContents, inetName);
		// Make sure bootp IS commented out
		addToFile("#bootp", "bootp", inetName, new String(""), false);

		messageLog.appendText("Sending SIGHUP to inetd.\n");
		String pidFileName;
		String pid = new String("");
		Process executing;
		if (testing) {
			pidFileName = "../../var/run/inetd.pid";
		} else {
			pidFileName = "/var/run/inetd.pid";
		};
		pid = readFromFile(pidFileName, true);
		if (pid.length() == 0) return;
		try {
			int exitVal = 0;
			executing = Runtime.getRuntime().exec("/bin/kill -HUP " + pid);
			exitVal = executing.waitFor();
			if (exitVal != 0 && !testing) {
				messageLog.appendText("Couldn't send SIGHUP to inetd. If you aren't going to reboot,\n"); 
				messageLog.appendText(" you'll have to do it manually by typing in: kill -HUP pid,\n");
				messageLog.appendText("where pid is the process id for inetd.\n");
			};
		} catch (IOException e) {
			messageLog.appendText("Couldn't send SIGHUP to inetd because of the following problem:\n");
			messageLog.appendText(e.toString() + "\n");
			messageLog.appendText("If you're not going to reboot, you'll have to do it manually by \n");
			messageLog.appendText("typing the following to the Unix shell: kill -HUP " + pid + ",\n");
			messageLog.appendText("where " + pid + " is the process id for inetd.\n");
		} catch (InterruptedException e) {
			messageLog.appendText("Interrupted while sending SIGHUP to inetd.\n");
		};
	};

	private void makeSwapSpaces(long numberOfAddrs, String size, 
		String directoryName, long addr, boolean updateServer) {
		String mkSwap;
		String swapProgram;
		Runtime rt;
		Process executing;
		int linebreak = 0;
		File swapDir;
		
		messageLog.appendText("Making swap spaces ");
		swapProgram = directoryName + "/mkswap ";
		rt = Runtime.getRuntime();
		swapDir = new File(directoryName + "/swap");
		swapDir.mkdirs();
		if (updateServer) {
			String[] swapFiles = swapDir.list();
			for (int i=0; i < swapFiles.length; i++) {
				File thisFile = new File(swapDir + "/" + swapFiles[i]);
				thisFile.delete();
			};
		};
		for (long i=0; i < numberOfAddrs; i++) {
			mkSwap = directoryName + "/swap/swap." + addrToString(addr) + " ";	
			linebreak++;
			if (linebreak == 80) {
				messageLog.appendText("\n");
				linebreak = 0;
			};
			messageLog.appendText(".");
			try {
				int exitVal;
				executing = rt.exec(swapProgram + mkSwap + size);
				exitVal = executing.waitFor();
				if (exitVal != 0) {
					messageLog.appendText("The following problem was reported by ./mkswap when making a swap file: ");
					messageLog.appendText(Integer.toString(exitVal));
					messageLog.appendText("\n");
				};
			} catch (IOException e) {
				messageLog.appendText("The following problem was reported by the Java runtime environment while creating ");
				messageLog.appendText(mkSwap);
				messageLog.appendText("The exception is " + e.toString());
				messageLog.appendText("\n");
			} catch (InterruptedException e) {
				messageLog.appendText("Interrupted while making a swap space");
			};
			addr++;
		};
		messageLog.appendText("\n");
	};

	private void setupDHCP(String gateway, String domain, String dnsHost, 
		String dnsAddr, long baseAddress, long numberOfAddresses, 
		String directory, String localHost, String localAddress, boolean doIt) {
		if (!doIt) {
			messageLog.appendText("Creating template dhcpd.conf file. It will appear in this directory as dhcpd.conf.template.\n");
		} else {
			messageLog.appendText("Creating /etc/dhcpd.conf.\n");
		};
		String dhcpConf = "# In this configuration the local host is the DHCP server, the bootserver,\n";
		dhcpConf = dhcpConf + "# and the NFS server for client root and swap partitions.\n\n";
		dhcpConf = dhcpConf + "# If the DHCP server, the bootserver, or the NFS server are on another host,\n";
		dhcpConf = dhcpConf + "# you will need to modify this file accordingly.\n";
		dhcpConf = dhcpConf + "# This is the hostname of the DHCP server\n";
		dhcpConf = dhcpConf + "server-identifier ";
		dhcpConf = dhcpConf + localHost + ";\n";
		dhcpConf = dhcpConf + "deny booting;\n";
		dhcpConf = dhcpConf + "default-lease-time 36000; # 10 hours\n";
		dhcpConf = dhcpConf + "max-lease-time 36000; # 10 hours\n\n";
		dhcpConf = dhcpConf + "# DHCP Server Name (optional)\n";
		dhcpConf = dhcpConf + "# server-name \"" + localHost + "\";\n\n"; 
		dhcpConf = dhcpConf + "# Boot Server IP Address. Needed if the boot server is not the DHCP server\n";
		dhcpConf = dhcpConf + "# next-server " + localAddress + ";\n\n";
		if (gateway.length() != 0) {
			dhcpConf = dhcpConf + "option routers " + gateway + ";\n";
		};
		if (dnsHost.length() != 0 || dnsAddr.length() != 0) {
			dhcpConf = dhcpConf + "option domain-name-servers ";
			if (dnsHost.length() != 0) {
				dhcpConf = dhcpConf + dnsHost;
			} else if (dnsAddr.length() != 0) {
				dhcpConf = dhcpConf + dnsAddr;
			};
			dhcpConf = dhcpConf + ";\n";
		};
		dhcpConf = dhcpConf + "option domain-name " + "\"" + domain + "\";\n";
		dhcpConf = dhcpConf + getSubnetInfo(subnetSpec.getText(), baseAddress, numberOfAddresses);	
		dhcpConf = dhcpConf + "vendor-class \"DNA\" {\n    filename \"/usr/tftpboot/netbsd\";\n";
		dhcpConf = dhcpConf + "    allow booting;\n";
		dhcpConf = dhcpConf + "    option    root-path    \"";
		dhcpConf = dhcpConf + localAddress + ":" + directory +
			"/ncroot/root\";\n";
		dhcpConf = dhcpConf + "    option    extensions-path \"";
		dhcpConf = dhcpConf + localAddress + ":" + directory + "/swap/swap.%s\";\n}\n";
		// Now we have all of the data, commit it to the file. If dhcpd is to
		// be configured and installed, touch the /var/db/dhcpd.leases file and
		// add dhcpd to rc.local.
		if (!doIt) {
			writeFile(dhcpConf, "./dhcpd.conf.template");
		} else {
			if (testing) {
				writeFile(dhcpConf, "../../etc/dhcpd.conf");
			} else {
				writeFile(dhcpConf, "/etc/dhcpd.conf");
			};
			try {
				Process executing;
				int exitVal;
				messageLog.appendText("Creating /var/db/dhcpd.leases \n");
				if (testing) {
					File dbDir = new File("../../var/db");
					dbDir.mkdirs();
					executing = Runtime.getRuntime().exec(
						"/usr/bin/touch ../../var/db/dhcpd.leases\n");
				} else {
					File dbDir = new File("/var/db");
					dbDir.mkdirs();
					executing = Runtime.getRuntime().exec(
						"/usr/bin/touch /var/db/dhcpd.leases\n");
				};
				exitVal = executing.waitFor();
				if (exitVal != 0) {
					messageLog.appendText("Couldn't create /var/db/dhcpd.leases, \n");
					messageLog.appendText("You'll need to do it manually by typing the following to the Unix shell:\n");
					messageLog.appendText("touch /var/db/dhcpd.leases\n");
				};
			} catch (IOException e) {
				messageLog.appendText("Couldn't create /var/db/dhcpd.leases because of the following problem:\n");
				messageLog.appendText(e.toString() + "\n");
				messageLog.appendText("You'll need to do it manually by typing the following to the Unix shell:\n");
				messageLog.appendText("touch /var/db/dhcpd.leases\n");
			} catch (InterruptedException e) {
				messageLog.appendText("Interrupted while trying to touch /var/db/dhcpd.leases\n");
			};
			if (testing) {
				addToFile(directory + "/dhcp/dhcpd", "dhcpd",
					"../../etc/rc.local", "local stuff here", true);
			} else {
				addToFile(directory + "/dhcp/dhcpd", "dhcpd", "/etc/rc.local",
					"local stuff here", true);
			};
		};
	};

	// Make sure we're in the proper directory.
	private void checkDirectory() throws InputException {
		File masterDir = new File("./ncroot/root");
		if (!masterDir.exists()) {
			messageLog.appendText("This program must be run in the directory that contains doConfig. This directory must also contain the ncroot subdirectory.\n");
			throw new InputException();
		};
	};

	// Get the exact name of the current directory (i.e. the name can't be a link).
	private String getDirectory() throws InputException {
		String directoryName;
		String tempString;
		
		File masterDir = new File(".");
		directoryName = masterDir.getAbsolutePath();
		if (directoryName.length() > 2) {
			// remove trailing /.
			tempString = directoryName.substring(0, 
				directoryName.length()-2);
			directoryName = tempString;
		};
		return directoryName;
	};

	// Get the text for the subnet, subnetMask, starting address and ending
	// address for the dhcpd.conf file.
	private String getSubnetInfo(String subnet, long address, long numAllocated) {
		String returnValue = new String("subnet ");
		int slashPos = subnet.indexOf("/");
		if (slashPos == -1) {
			int spacePos = subnet.indexOf(" ");
			returnValue = returnValue + subnet.substring(0, spacePos);
			returnValue = returnValue + " netmask " + subnet.substring(spacePos+1, subnet.length()) + " {\n";
		} else {
			String tempString = subnet.substring(0, slashPos);
			long subnetBase = addrToLong(tempString);
			tempString = subnet.substring(slashPos+1, subnet.length());
			long mask = 0xFFFFFFFF & (~Long.parseLong(tempString));
			returnValue = returnValue + addrToString(subnetBase);
			returnValue = returnValue + " netmask " + addrToString(mask) + " {\n";
		};
		returnValue = returnValue + "    range " + addrToString(address);
		returnValue = returnValue + " " + addrToString(address + numAllocated-1) + ";\n}\n";
		return returnValue;
	};

	// Convert a long to a dotted decimal network address
	private String addrToString(long toConvert) {
		String returnValue = new String("");
		long tempLong = toConvert & 0xFF000000;
		tempLong = tempLong >> 24;
		tempLong = tempLong & 0xFF;
		returnValue = returnValue + Long.toString(tempLong) + ".";
		tempLong = toConvert & 0xFF0000;
		tempLong = tempLong >> 16;
		returnValue = returnValue + Long.toString(tempLong) + ".";
		tempLong = toConvert & 0xFF00;
		tempLong = tempLong >> 8;
		returnValue = returnValue + Long.toString(tempLong) + ".";
		tempLong = toConvert & 0xFF;
		returnValue = returnValue + Long.toString(tempLong);
		return returnValue;
	};

	// Get the size of each swap file as a string, convert it to an
	// integer, multiply by 1 meg, and the convert it back to a string.
	private String checkAndConvertSize() throws InputException {
		String size = sizeField.getText();
		if (size.length() == 0) {
			messageLog.appendText("A size for the swap files must be supplied.\n");
			throw new InputException();
		};
		try {
			long tempLong = Long.parseLong(size);
			tempLong = tempLong * 1024 * 1024;
			size = Long.toString(tempLong);
		} catch (NumberFormatException exc) {
			messageLog.appendText("The swap file size must be an integer.\n");
			throw new InputException();
		};
		return size;
	};

	// Get the number of addresses to allocate as a string and
	// convert it to a long.
	private long checkAndConvertAddresses() throws InputException {
		String tempString;
		long returnValue = 0;
		try {
			tempString = numAddresses.getText();
			if (tempString.length() == 0) {
				messageLog.appendText("The number of addresses to assign to NCs must be supplied.\n");
				throw new InputException();
			};
			returnValue = Integer.parseInt(tempString);
		} catch (NumberFormatException exc) {
			messageLog.appendText("The number of addresses to assign to NCs must be an integer.\n");
			throw new InputException();
		};
		return returnValue;
	};

	// If we were given the hostname as a dotted decimal, it will be
	// the same as the hostaddress. If this is the case, we don't want
	// to write the same value twice in the resolv.conf file.
	private String checkHostName(String hostAddress, String hostName) {
		 String returnString;
		if (hostAddress.equals(hostName)) {
			returnString = new String("");
		} else {
			returnString = hostName;
		};
		return returnString;
	};
	
	// Check to see that we were given a valid network address for the
	// IP gateway.
	private void checkGateway(String gatewayAddr) throws InputException {
		InetAddress gateway;
		try {
			gateway = InetAddress.getByName(gatewayAddr);
		} catch (UnknownHostException exc) {
			messageLog.appendText(" Can't look up gateway hostname. If there's no DNS, use IP address format.\n");
			messageLog.appendText("The exception is: " + exc.toString() + "\n");
			throw new InputException();
		}
	};

	// If the script isn't there, bad things happen to this Java program!
	private void checkSwapScript(String directoryName) throws InputException {
		File swapScript = new File(directoryName + "/mkswap");
		if (!swapScript.exists()) {
			messageLog.appendText("The ./mkswap file doesn't exist in " + directoryName + ".\n");
			messageLog.appendText("No swap files can be created without it.\n");
			throw new InputException();
		};
	};

	// Get the local subnet and verify that the range of
	// addresses we're about to allocate is in this subnet.
	private long getBaseAndCheckAlloc(long numberOfAddresses)
		throws InputException {
		String subnet = subnetSpec.getText();
                int slashPos = subnet.indexOf("/");
		long mask;
		long subnetBase = 0;
		String baseSubnetString;
		String tempString;
		long returnValue = 0;
		if (slashPos != -1) {
			baseSubnetString = subnet.substring(0, slashPos);
			tempString = subnet.substring(slashPos+1, subnet.length());
			try {
				mask = (long)Math.pow(2, (32 - Integer.parseInt(tempString)))-1;
			} catch (NumberFormatException exc) {
				messageLog.appendText("The format for the subnet is incorrect. It should be a network address in dotted decimal form.\n");
				throw new InputException();
			};
			subnetBase = addrToLong(baseSubnetString);
		} else {
			int spacePos = subnet.indexOf(" ");
			if (spacePos == -1) {
				messageLog.appendText("The format for the subnet is incorrect. It should be a network address in dotted decimal form.\n");
				throw new InputException();
			};
			baseSubnetString = subnet.substring(0, spacePos);
			subnetBase = addrToLong(baseSubnetString);
			tempString = subnet.substring(spacePos+1, subnet.length());
			mask = (long)((Math.pow(2, 32) - addrToLong(tempString)) - 1);
		};
		if (subnetBase == 0) {
			messageLog.appendText("The address specified for the subnet is invalid.\n");
			throw new InputException();
		};
		long tempSubnet = subnetBase & mask;
		if (tempSubnet != 0) {
			messageLog.appendText("The last byte in the subnet specification must be zero.\n");
			throw new InputException();
		};
		subnetBase = subnetBase | mask;
		String baseAddressString = baseAddr.getText();
		returnValue = addrToLong(baseAddressString);
		if (returnValue == 0) {
			messageLog.appendText("The first address to assign to NCs is invalid.\n");
			throw new InputException();
		};
		long tempLong = returnValue | mask;
		if (tempLong != subnetBase) {
			messageLog.appendText("The first address you wanted to assign to NCs is not on this subnet. It should be.\n");
			throw new InputException();
		};
		if ((returnValue & mask) == 0) {
			messageLog.appendText("The first address you wanted to assign to NCs is illegal\n");
			messageLog.appendText("because you can't allocate zero as the host number on a subnet.\n");
			throw new InputException();
		};
		if (((returnValue + numberOfAddresses) & mask) == mask) {
			messageLog.appendText("The number of addresses you wanted to assign to NCs exceeds the number allowed on this subnet.\n");
			messageLog.appendText("You'll need to reduce this number.\n");
			throw new InputException();
		};
		tempLong = returnValue + numberOfAddresses;
		tempLong = tempLong | mask;
		if (tempLong != subnetBase) {
			messageLog.appendText("The number of addresses you wanted to assign to NCs exceeds the number allowed on this subnet.\n");
			messageLog.appendText("You'll need to reduce this number.\n");
			throw new InputException();
		};
		return returnValue;
	};
};

class InputException extends Exception {
	public InputException() {}
};

class X11Filter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("X11") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		if (name.startsWith("x11") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class NCIFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("nci") && !name.startsWith("nci-root") 
			&& name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class NCIRootFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("nci-root") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class JavaFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("java") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class RootFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("root") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class UsrFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("usr") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};

class DHCPFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		boolean acceptIt = false;
		if (name.startsWith("dhcp-f") && name.endsWith(".tar.gz")) {
			acceptIt = true;
		};
		return acceptIt;
	};
};
